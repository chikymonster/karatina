# How to Email This Package to Yourself

## 🚀 Super Easy Method (Recommended)

### **Option 1: Double-Click the Batch File**

1. **Double-click:** `EMAIL-ME.bat`
2. **Follow the prompts:**
   - Enter your email address
   - Enter SMTP server (e.g., smtp.gmail.com, smtp.office365.com)
   - Confirm to send
3. **Done!** Check your inbox

### **Option 2: One PowerShell Command**

```powershell
.\Send-WSUSReportingPackage.ps1 `
    -EmailTo "your.email@company.com" `
    -EmailFrom "wsus@company.com" `
    -SmtpServer "smtp.company.com"
```

**That's it!** The script will:
- ✅ Create a ZIP file with all 14 files
- ✅ Send beautiful HTML email with instructions
- ✅ Attach the ZIP (typically 50-100 KB)
- ✅ Clean up the ZIP file (optional)

---

## 📧 Common SMTP Server Settings

### **Office 365 / Microsoft 365**
```powershell
.\Send-WSUSReportingPackage.ps1 `
    -EmailTo "you@company.com" `
    -EmailFrom "you@company.com" `
    -SmtpServer "smtp.office365.com" `
    -SmtpPort 587 `
    -UseSsl
```

### **Gmail** (Requires App Password)
```powershell
.\Send-WSUSReportingPackage.ps1 `
    -EmailTo "you@gmail.com" `
    -EmailFrom "you@gmail.com" `
    -SmtpServer "smtp.gmail.com" `
    -SmtpPort 587 `
    -UseSsl
```

### **Exchange Server (Internal)**
```powershell
.\Send-WSUSReportingPackage.ps1 `
    -EmailTo "you@company.com" `
    -EmailFrom "wsus@company.com" `
    -SmtpServer "mail.company.local"
```

### **Generic SMTP**
```powershell
.\Send-WSUSReportingPackage.ps1 `
    -EmailTo "you@company.com" `
    -EmailFrom "wsus@company.com" `
    -SmtpServer "smtp.yourserver.com" `
    -SmtpPort 25
```

---

## 🎯 Advanced Options

### **Send to Multiple People**
```powershell
.\Send-WSUSReportingPackage.ps1 `
    -EmailTo "admin1@company.com,admin2@company.com,boss@company.com" `
    -EmailFrom "wsus@company.com" `
    -SmtpServer "smtp.company.com"
```

### **Custom Subject Line**
```powershell
.\Send-WSUSReportingPackage.ps1 `
    -EmailTo "you@company.com" `
    -EmailFrom "wsus@company.com" `
    -SmtpServer "smtp.company.com" `
    -Subject "WSUS Reporting - Install This ASAP!"
```

### **Custom ZIP Filename**
```powershell
.\Send-WSUSReportingPackage.ps1 `
    -EmailTo "you@company.com" `
    -EmailFrom "wsus@company.com" `
    -SmtpServer "smtp.company.com" `
    -ZipFileName "MyWSUSReports.zip"
```

### **Keep ZIP File After Sending**
```powershell
.\Send-WSUSReportingPackage.ps1 `
    -EmailTo "you@company.com" `
    -EmailFrom "wsus@company.com" `
    -SmtpServer "smtp.company.com" `
    -KeepZipFile
```

---

## ❌ Troubleshooting

### **Error: "Send-MailMessage : Unable to connect"**

**Problem:** Can't reach SMTP server

**Solutions:**
```powershell
# 1. Test SMTP connectivity
Test-NetConnection -ComputerName "smtp.company.com" -Port 25

# 2. Try different ports
-SmtpPort 587   # Common for TLS
-SmtpPort 465   # Common for SSL
-SmtpPort 25    # Standard SMTP

# 3. Add SSL if required
-UseSsl
```

### **Error: "Mailbox unavailable" or "Relay denied"**

**Problem:** SMTP server doesn't allow anonymous relay

**Solutions:**

**Option A - Use authenticated SMTP:**
The script currently uses anonymous SMTP. For authenticated SMTP, you'll need to modify it slightly:

```powershell
# In PowerShell, run with credentials:
$cred = Get-Credential
Send-MailMessage -To "you@company.com" `
    -From "wsus@company.com" `
    -Subject "WSUS Package" `
    -Body "See attachment" `
    -Attachments "WSUS-Reporting-Solution.zip" `
    -SmtpServer "smtp.company.com" `
    -Port 587 `
    -UseSsl `
    -Credential $cred
```

**Option B - Whitelist the server IP:**
Contact your email admin to allow relay from your WSUS server's IP address.

**Option C - Use internal mail server:**
Use your company's internal Exchange server which typically allows relay from internal IPs.

### **Error: "Execution Policy"**

**Problem:** PowerShell won't run the script

**Solution:**
```powershell
# Run with bypass
powershell.exe -ExecutionPolicy Bypass -File .\Send-WSUSReportingPackage.ps1 -EmailTo "you@company.com" -EmailFrom "wsus@company.com" -SmtpServer "smtp.company.com"
```

### **Error: "ZIP file too large for email"**

**Problem:** Some email servers limit attachment size

**Solution:** The ZIP is tiny (~50-100 KB), but if blocked:
```powershell
# 1. Upload to file share instead
Copy-Item "WSUS-Reporting-Solution.zip" "\\fileserver\share\WSUS\"

# 2. Or use cloud storage
# Manually upload to OneDrive, Dropbox, etc. and email the link
```

---

## 📋 Manual Alternative (If SMTP Doesn't Work)

If email fails, you can manually create and download the ZIP:

### **Create ZIP Manually:**

**Option 1 - PowerShell:**
```powershell
# Compress all files
Compress-Archive -Path *.ps1,*.sql,*.md -DestinationPath "WSUS-Reporting-Solution.zip"
```

**Option 2 - Windows Explorer:**
1. Select all .ps1, .sql, and .md files
2. Right-click → "Send to" → "Compressed (zipped) folder"
3. Name it: `WSUS-Reporting-Solution.zip`

**Then:**
- Email the ZIP file manually through Outlook/webmail
- Upload to OneDrive/Google Drive/Dropbox
- Copy to USB drive
- Transfer via network share

---

## 🎯 What Gets Emailed

The email includes:

**Subject:** WSUS Reporting Solution - Complete Package

**Body:** Beautiful HTML email with:
- Package overview
- Quick start instructions
- Feature list
- Requirements
- Documentation links

**Attachment:** WSUS-Reporting-Solution.zip containing:
- 6 SQL view scripts
- 5 PowerShell scripts
- 3 Documentation files
- Total size: ~50-100 KB

---

## ✅ Verification

After sending, verify:

1. **Check Sent Items** - Email should be in your sent folder
2. **Check Inbox** - Email yourself to test end-to-end
3. **Download ZIP** - Make sure attachment downloads correctly
4. **Extract ZIP** - Verify all 14 files are present
5. **Read README** - Confirms everything is working

---

## 🔐 Security Notes

**What's in the ZIP:**
- ✅ PowerShell scripts (safe - just text)
- ✅ SQL scripts (safe - just text)
- ✅ Documentation (safe - just text)
- ❌ No executables
- ❌ No macros
- ❌ No sensitive data

**The ZIP is safe to email** - it contains only text files and documentation.

---

## 💡 Pro Tips

1. **Email to personal account** - Easy to access from anywhere
2. **CC your team** - Share with colleagues in one shot
3. **Keep ZIP on network share** - Everyone can access it
4. **Upload to internal portal** - Make it available company-wide
5. **Add to documentation site** - Link in your runbooks

---

## 🆘 Still Having Issues?

If you absolutely can't get email working, here are alternatives:

### **Alternative 1: Network Share**
```powershell
# Create ZIP
Compress-Archive -Path *.ps1,*.sql,*.md -DestinationPath "\\fileserver\IT\WSUS-Reporting-Solution.zip"
```

### **Alternative 2: USB Drive**
```powershell
# Create ZIP on USB
Compress-Archive -Path *.ps1,*.sql,*.md -DestinationPath "E:\WSUS-Reporting-Solution.zip"
```

### **Alternative 3: Cloud Storage**
```powershell
# Create ZIP
Compress-Archive -Path *.ps1,*.sql,*.md -DestinationPath "$env:USERPROFILE\Downloads\WSUS-Reporting-Solution.zip"

# Then upload to:
# - OneDrive
# - Google Drive  
# - Dropbox
# - SharePoint
```

### **Alternative 4: Direct Copy**
```powershell
# Just copy the entire folder
Copy-Item -Path "C:\WSUSReporting" -Destination "\\fileserver\IT\WSUS-Reporting" -Recurse
```

---

## 📞 Quick Reference

**Fastest method:**
```powershell
.\Send-WSUSReportingPackage.ps1 -EmailTo "you@company.com" -EmailFrom "wsus@company.com" -SmtpServer "smtp.company.com"
```

**Or just double-click:** `EMAIL-ME.bat`

**Manual ZIP:**
```powershell
Compress-Archive -Path *.ps1,*.sql,*.md -DestinationPath "WSUS-Reporting-Solution.zip"
```

---

**Need help?** The files are small and safe. Any standard file transfer method works!
