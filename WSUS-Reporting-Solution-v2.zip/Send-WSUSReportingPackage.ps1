<#
.SYNOPSIS
    Zip and Email WSUS Reporting Solution
    
.DESCRIPTION
    Packages all WSUS reporting files into a single ZIP file and emails it.
    Perfect for sharing the complete solution with colleagues or sending to yourself.
    
.PARAMETER EmailTo
    Recipient email address(es) - comma separated for multiple
    
.PARAMETER EmailFrom
    Sender email address
    
.PARAMETER SmtpServer
    SMTP server address
    
.PARAMETER Subject
    Email subject (optional)
    
.PARAMETER ZipFileName
    Name for the ZIP file (optional, default: WSUS-Reporting-Solution.zip)
    
.EXAMPLE
    .\Send-WSUSReportingPackage.ps1 -EmailTo "me@company.com" -EmailFrom "wsus@company.com" -SmtpServer "smtp.company.com"
    
.EXAMPLE
    # Send to multiple recipients
    .\Send-WSUSReportingPackage.ps1 -EmailTo "admin1@company.com,admin2@company.com" -EmailFrom "wsus@company.com" -SmtpServer "smtp.company.com"
    
.NOTES
    Creates ZIP in current directory, emails it, then optionally deletes the ZIP.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$EmailTo,
    
    [Parameter(Mandatory=$true)]
    [string]$EmailFrom,
    
    [Parameter(Mandatory=$true)]
    [string]$SmtpServer,
    
    [Parameter(Mandatory=$false)]
    [int]$SmtpPort = 25,
    
    [Parameter(Mandatory=$false)]
    [string]$Subject = "WSUS Reporting Solution - Complete Package",
    
    [Parameter(Mandatory=$false)]
    [string]$ZipFileName = "WSUS-Reporting-Solution.zip",
    
    [Parameter(Mandatory=$false)]
    [switch]$UseSsl,
    
    [Parameter(Mandatory=$false)]
    [switch]$KeepZipFile
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "╔══════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║                                                          ║" -ForegroundColor Cyan
Write-Host "║       ZIP & EMAIL WSUS REPORTING SOLUTION                ║" -ForegroundColor Cyan
Write-Host "║                                                          ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# Get current directory
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$zipPath = Join-Path $scriptDir $ZipFileName

# Check if ZIP already exists
if (Test-Path $zipPath) {
    Write-Host "⚠️  ZIP file already exists: $zipPath" -ForegroundColor Yellow
    $response = Read-Host "Overwrite? (Y/N)"
    if ($response -ne 'Y' -and $response -ne 'y') {
        Write-Host "Aborted." -ForegroundColor Red
        exit 1
    }
    Remove-Item $zipPath -Force
}

# Step 1: Create ZIP file
Write-Host "[1/3] Creating ZIP package..." -ForegroundColor Cyan

# Get all files to include (exclude the send script itself and any existing ZIPs)
$filesToZip = Get-ChildItem -Path $scriptDir -File | Where-Object { 
    $_.Extension -match '\.(ps1|sql|md)$' -and 
    $_.Name -ne "Send-WSUSReportingPackage.ps1" 
}

Write-Host "  Including files:" -ForegroundColor Gray
foreach ($file in $filesToZip) {
    Write-Host "    - $($file.Name)" -ForegroundColor Gray
}

try {
    # Use .NET to create ZIP (works on PowerShell 5.0+)
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    
    $compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
    $zip = [System.IO.Compression.ZipFile]::Open($zipPath, [System.IO.Compression.ZipArchiveMode]::Create)
    
    foreach ($file in $filesToZip) {
        $entryName = $file.Name
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $file.FullName, $entryName, $compressionLevel) | Out-Null
    }
    
    $zip.Dispose()
    
    $zipSize = [math]::Round((Get-Item $zipPath).Length / 1MB, 2)
    Write-Host "  ✓ ZIP created successfully: $zipPath ($zipSize MB)" -ForegroundColor Green
}
catch {
    Write-Host "  ✗ Failed to create ZIP file" -ForegroundColor Red
    Write-Host "  Error: $_" -ForegroundColor Red
    exit 1
}

# Step 2: Prepare email
Write-Host ""
Write-Host "[2/3] Preparing email..." -ForegroundColor Cyan

$emailBody = @"
<html>
<head>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; color: #333; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 5px; }
        .content { padding: 20px; }
        .file-list { background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .file-list ul { margin: 10px 0; }
        .file-list li { margin: 5px 0; }
        .footer { background: #f9f9f9; padding: 15px; border-top: 2px solid #667eea; margin-top: 20px; font-size: 0.9em; color: #666; }
        .highlight { background: #fff3cd; padding: 10px; border-left: 4px solid #ffc107; margin: 15px 0; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🛡️ WSUS Reporting Solution</h1>
        <p>Complete Package - Ready to Deploy</p>
    </div>
    
    <div class="content">
        <h2>Package Contents</h2>
        <p>Attached is the complete WSUS Reporting Solution. This package includes everything you need to replace WSUS's terrible native reports with beautiful, auditor-friendly dashboards.</p>
        
        <div class="file-list">
            <strong>📦 What's Included ($(($filesToZip | Measure-Object).Count) files):</strong>
            <ul>
                <li><strong>6 SQL Views</strong> - Optimized queries for SUSDB</li>
                <li><strong>4 PowerShell Scripts</strong> - Report generation, CSV export, automation, health check</li>
                <li><strong>1 Installation Script</strong> - One-click deployment</li>
                <li><strong>3 Documentation Files</strong> - README, Deployment Guide, Quick Reference</li>
            </ul>
        </div>
        
        <h2>🚀 Quick Start</h2>
        <ol>
            <li><strong>Extract the ZIP</strong> to your WSUS server (e.g., C:\WSUSReporting\)</li>
            <li><strong>Open PowerShell as Administrator</strong></li>
            <li><strong>Run:</strong>
                <pre style="background: #2d2d2d; color: #f8f8f2; padding: 10px; border-radius: 5px; overflow-x: auto;">cd C:\WSUSReporting
.\Install-WSUSReporting.ps1 -SqlServer "YOUR_SQL_SERVER"</pre>
            </li>
            <li><strong>Done!</strong> Your first report opens automatically in your browser</li>
        </ol>
        
        <div class="highlight">
            <strong>⚡ Pro Tip:</strong> Read the README.md file first for a complete overview. It's in the ZIP!
        </div>
        
        <h2>✨ Features</h2>
        <ul>
            <li>📊 Beautiful HTML reports with interactive charts</li>
            <li>📧 Automated weekly email delivery</li>
            <li>📈 Executive dashboard with compliance metrics</li>
            <li>🎯 Auditor-approved compliance data</li>
            <li>📁 CSV exports for detailed analysis</li>
            <li>🤖 Zero manual work once configured</li>
        </ul>
        
        <h2>📋 Requirements</h2>
        <ul>
            <li>Windows Server with WSUS installed</li>
            <li>SQL Server (not Windows Internal Database)</li>
            <li>PowerShell 5.1+ (built into Server 2016+)</li>
            <li>Administrator rights</li>
            <li>Network access to SQL Server</li>
        </ul>
        
        <h2>📚 Documentation</h2>
        <p>All documentation is included in the ZIP:</p>
        <ul>
            <li><strong>README.md</strong> - Quick start and overview</li>
            <li><strong>DEPLOYMENT-GUIDE.md</strong> - Complete setup instructions</li>
            <li><strong>QUICK-REFERENCE.md</strong> - Command cheat sheet</li>
        </ul>
    </div>
    
    <div class="footer">
        <p><strong>Package Details:</strong></p>
        <p>📦 ZIP File: $ZipFileName ($zipSize MB)<br>
        📅 Created: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')<br>
        📁 Files: $(($filesToZip | Measure-Object).Count) total</p>
        
        <p style="margin-top: 15px;"><em>Stop suffering with WSUS's terrible native reports. Deploy this solution today! 🎉</em></p>
    </div>
</body>
</html>
"@

# Step 3: Send email
Write-Host ""
Write-Host "[3/3] Sending email..." -ForegroundColor Cyan
Write-Host "  To: $EmailTo" -ForegroundColor Gray
Write-Host "  From: $EmailFrom" -ForegroundColor Gray
Write-Host "  SMTP: $SmtpServer" -ForegroundColor Gray
Write-Host "  Attachment: $zipPath ($zipSize MB)" -ForegroundColor Gray

try {
    $emailParams = @{
        To          = $EmailTo.Split(',')
        From        = $EmailFrom
        Subject     = $Subject
        Body        = $emailBody
        BodyAsHtml  = $true
        SmtpServer  = $SmtpServer
        Port        = $SmtpPort
        Attachments = $zipPath
    }
    
    if ($UseSsl) {
        $emailParams.Add('UseSsl', $true)
    }
    
    Send-MailMessage @emailParams
    
    Write-Host "  ✓ Email sent successfully!" -ForegroundColor Green
}
catch {
    Write-Host "  ✗ Failed to send email" -ForegroundColor Red
    Write-Host "  Error: $_" -ForegroundColor Red
    Write-Host ""
    Write-Host "  Troubleshooting:" -ForegroundColor Yellow
    Write-Host "    - Verify SMTP server address is correct" -ForegroundColor White
    Write-Host "    - Check if SMTP requires authentication (script uses anonymous)" -ForegroundColor White
    Write-Host "    - Try different port: -SmtpPort 587 (or 465 for SSL)" -ForegroundColor White
    Write-Host "    - Add -UseSsl if using encrypted connection" -ForegroundColor White
    Write-Host ""
    Write-Host "  The ZIP file is still available at: $zipPath" -ForegroundColor Cyan
    exit 1
}

# Step 4: Cleanup (optional)
Write-Host ""
if ($KeepZipFile) {
    Write-Host "✓ ZIP file kept at: $zipPath" -ForegroundColor Green
} else {
    Write-Host "Cleaning up..." -ForegroundColor Gray
    $response = Read-Host "Delete ZIP file? (Y/N)"
    if ($response -eq 'Y' -or $response -eq 'y') {
        Remove-Item $zipPath -Force
        Write-Host "  ✓ ZIP file deleted" -ForegroundColor Green
    } else {
        Write-Host "  ZIP file kept at: $zipPath" -ForegroundColor Cyan
    }
}

Write-Host ""
Write-Host "╔══════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║                                                          ║" -ForegroundColor Green
Write-Host "║                  EMAIL SENT SUCCESSFULLY!                ║" -ForegroundColor Green
Write-Host "║                                                          ║" -ForegroundColor Green
Write-Host "╚══════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""
Write-Host "Check your inbox: $EmailTo" -ForegroundColor Cyan
Write-Host ""
